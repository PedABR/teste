package lp2;

public class ProdutoID {

    private String nome;
    private String descrição;

    public ProdutoID (String nome, String descrição) {
        this.descrição = descrição;
        this.nome = nome;
    }
}
